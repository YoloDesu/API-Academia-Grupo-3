--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.4
-- Dumped by pg_dump version 15.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE academia;
--
-- Name: academia; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE academia WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'Portuguese_Brazil.1252';


ALTER DATABASE academia OWNER TO postgres;

\connect academia

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO pg_database_owner;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: instrutor; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.instrutor (
    instrutorid integer NOT NULL,
    rg double precision,
    telefoneid integer,
    nomeinstrutor character varying(255)
);


ALTER TABLE public.instrutor OWNER TO postgres;

--
-- Name: instrutor_instrutorid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.instrutor_instrutorid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.instrutor_instrutorid_seq OWNER TO postgres;

--
-- Name: instrutor_instrutorid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.instrutor_instrutorid_seq OWNED BY public.instrutor.instrutorid;


--
-- Name: telefone; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.telefone (
    numero double precision,
    telefoneid integer NOT NULL,
    telefoneinstrutorid integer
);


ALTER TABLE public.telefone OWNER TO postgres;

--
-- Name: telefone_telefoneid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.telefone_telefoneid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.telefone_telefoneid_seq OWNER TO postgres;

--
-- Name: telefone_telefoneid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.telefone_telefoneid_seq OWNED BY public.telefone.telefoneid;


--
-- Name: turma; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.turma (
    instrutorid integer,
    turmaid integer NOT NULL,
    diasemana character varying(255),
    nomedisciplina character varying(255)
);


ALTER TABLE public.turma OWNER TO postgres;

--
-- Name: turma_turmaid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.turma_turmaid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.turma_turmaid_seq OWNER TO postgres;

--
-- Name: turma_turmaid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.turma_turmaid_seq OWNED BY public.turma.turmaid;


--
-- Name: instrutor instrutorid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.instrutor ALTER COLUMN instrutorid SET DEFAULT nextval('public.instrutor_instrutorid_seq'::regclass);


--
-- Name: telefone telefoneid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.telefone ALTER COLUMN telefoneid SET DEFAULT nextval('public.telefone_telefoneid_seq'::regclass);


--
-- Name: turma turmaid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.turma ALTER COLUMN turmaid SET DEFAULT nextval('public.turma_turmaid_seq'::regclass);


--
-- Data for Name: instrutor; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.instrutor (instrutorid, rg, telefoneid, nomeinstrutor) FROM stdin;
\.
COPY public.instrutor (instrutorid, rg, telefoneid, nomeinstrutor) FROM '$$PATH$$/3339.dat';

--
-- Data for Name: telefone; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.telefone (numero, telefoneid, telefoneinstrutorid) FROM stdin;
\.
COPY public.telefone (numero, telefoneid, telefoneinstrutorid) FROM '$$PATH$$/3341.dat';

--
-- Data for Name: turma; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.turma (instrutorid, turmaid, diasemana, nomedisciplina) FROM stdin;
\.
COPY public.turma (instrutorid, turmaid, diasemana, nomedisciplina) FROM '$$PATH$$/3343.dat';

--
-- Name: instrutor_instrutorid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.instrutor_instrutorid_seq', 1, false);


--
-- Name: telefone_telefoneid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.telefone_telefoneid_seq', 1, false);


--
-- Name: turma_turmaid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.turma_turmaid_seq', 1, false);


--
-- Name: instrutor instrutor_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.instrutor
    ADD CONSTRAINT instrutor_pkey PRIMARY KEY (instrutorid);


--
-- Name: instrutor instrutor_telefoneid_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.instrutor
    ADD CONSTRAINT instrutor_telefoneid_key UNIQUE (telefoneid);


--
-- Name: telefone telefone_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.telefone
    ADD CONSTRAINT telefone_pkey PRIMARY KEY (telefoneid);


--
-- Name: turma turma_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.turma
    ADD CONSTRAINT turma_pkey PRIMARY KEY (turmaid);


--
-- Name: instrutor fk5kaby7l0n2b4whc90pna2gkul; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.instrutor
    ADD CONSTRAINT fk5kaby7l0n2b4whc90pna2gkul FOREIGN KEY (telefoneid) REFERENCES public.telefone(telefoneid);


--
-- Name: turma fktdgcs17eahekrqqk7wyru5h7j; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.turma
    ADD CONSTRAINT fktdgcs17eahekrqqk7wyru5h7j FOREIGN KEY (instrutorid) REFERENCES public.instrutor(instrutorid);


--
-- PostgreSQL database dump complete
--

